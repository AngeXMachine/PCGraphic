#include <gl/gl.h>
#include <math.h>
#include <string>
#include "game.hpp"
#include "texture.hpp"
#include "stb-master_lib/stb_image.h"
#include "stb-master_lib/stb_image.h"
#include <conio.h>
#include <windows.h>
Player player;

void Game(GLuint texture) {
    static float svertixFrame[] = { 0,0, 0,0, 0,0, 0,0 };
    static float TexCordFrame[] = { 0,0, 0,0, 0,0, 0,0 };
    static float tileCords[] = { 0,0, 0,0, 0,0, 0,0 };
    int go_up_key = GetKeyState('W');
    int go_left_key = GetKeyState('A');
    int go_right_key = GetKeyState('D');


    if (go_up_key < 0) player.jump();
    if (go_left_key < 0 || go_right_key < 0) {
        player.vx = 4;
        player.animation = 1;

        if( go_left_key < 0 ) player.direction = -1;
        else player.direction = 1;

    } else if (player.onGround) {
        player.vx = 0;
        player.animation = 0;
    }

    player.iter();

    svertixFrame[0] = svertixFrame[2] = player.x;
    svertixFrame[1] = svertixFrame[7] = player.y;
    svertixFrame[3] = svertixFrame[5] = player.y+player.h*player.scale;
    svertixFrame[4] = svertixFrame[6] = player.x+player.w*player.scale;

    TexCordFrame[3] = TexCordFrame[5] = player.animation/3.;
    TexCordFrame[1] = TexCordFrame[7] = (player.animation+1)/3.;
    if (player.direction == 1) {
        TexCordFrame[0] = TexCordFrame[2] = player.frame/8.;
        TexCordFrame[4] = TexCordFrame[6] = (player.frame+1)/8.;
    } else {
        TexCordFrame[4] = TexCordFrame[6] = player.frame/8.;
        TexCordFrame[0] = TexCordFrame[2] = (player.frame+1)/8.;
    }

    GlSettingsOn(texture);

    glVertexPointer(2,GL_FLOAT,0,svertixFrame);
    glTexCoordPointer(2,GL_FLOAT,0,TexCordFrame);
    glTexCoordPointer(2,GL_FLOAT,0,TexCordFrame);
    glDrawArrays(GL_TRIANGLE_FAN,0,4);

    glBindTexture(GL_TEXTURE_2D, 0);
    int rows = 22, columns = 40;
    for (int i=0; i<rows; i++) {
        for (int j=0; j<columns; j++) {
            if (TileMap[rows-i-1][j] == ' ') continue;
            if (TileMap[rows-i-1][j] == 'K') {
                tileCords[0] = tileCords[2] = j*32;
                tileCords[1] = tileCords[7] = i*32;
                tileCords[3] = tileCords[5] = (i+1)*32;
                tileCords[4] = tileCords[6] = (j+1)*32;

                glVertexPointer(2, GL_FLOAT, 0, tileCords);
                glColor3f(0.2f, 0.2f, 0.2f);
                glDrawArrays(GL_QUADS, 0, 4);
            }
        }
    }

    GlSettingsOff();
}
