#ifndef TEXTURE_H_INCLUDED
#define TEXTURE_H_INCLUDED

void Load_Texture( char *filename, GLuint *textureID, int swarp, int twarp, int filter);
void print_string(float x, float y, char *text, float r, float g, float b);

#endif // TEXTURE_H_INCLUDED
